<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kontakt - Zitto Restoran</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Početna</a></li>
                <li><a href="onama.php">O nama</a></li>
                <li><a href="jelovnik.php">Jelovnik</a></li>
                <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </nav>
    </header>
    <main class="kontakt-main">
        <h1>Kontakt</h1>
        <div class="contact-info">
            <p>Adresa: Kamenita ul. 4, 10000 Zagreb</p>
            <p>Telefon: +385 1 234 5678</p>
            <p>Email: info@zitto.hr</p>
            <p>Za rezervacije, molimo kontaktirajte nas putem telefona ili emaila. Radujemo se vašem dolasku!</p>
        </div>
        <div class="map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2780.773374237763!2d15.972617176738863!3d45.815796909910176!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4765d70294513f21%3A0xc35f604e4494c467!2sKamenita%20ul.%204%2C%2010000%2C%20Zagreb!5e0!3m2!1shr!2shr!4v1717505460079!5m2!1shr!2shr" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </main>
    
    <footer>
        <p>Tihana Kos, XML projekt 2024.</p>
    </footer>
</body>
</html>
