<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zitto Restoran</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Početna</a></li>
                <li><a href="onama.php">O nama</a></li>
                <li><a href="jelovnik.php">Jelovnik</a></li>
                <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </nav>
        <h1>Restoran Zitto</h1>
        <h2>Uživajte u vrhunskoj gastronomiji!</h2>
    </header>
  
    <img src="restoran.jpg" alt="Slika restorana">
    

    <footer>
        <p>Tihana Kos, XML projekt 2024.</p>
    </footer>
</body>
</html>
