<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>O nama - Zitto Restoran</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Početna</a></li>
                <li><a href="onama.php">O nama</a></li>
                <li><a href="jelovnik.php">Jelovnik</a></li>
                <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h1 class="naslov">O nama</h1>
        <p>Zitto restoran postoji već generacijama, nasljeđujući se u obitelji. Naša priča počinje davne 1920. godine kada je naš djed otvorio prvi restoran. Od tada, svaka generacija obitelji dodala je svoj pečat, stvarajući jedinstveno gastronomsko iskustvo koje danas možete iskusiti.</p>
        <p>Naša misija je pružiti gostima vrhunsko kulinarsko iskustvo koristeći samo najkvalitetnije sastojke. Uz tradicionalna jela, nudimo i moderne kulinarske kreacije koje zadovoljavaju sve ukuse.</p>
    </main>

    <footer>
        <p>Tihana Kos, XML projekt 2024.</p>
    </footer>
</body>
</html>
