<?php
$xml = simplexml_load_file('menu.xml') or die("Error: Cannot create object");
?>
<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <title>Jelovnik</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Početna</a></li>
                <li><a href="onama.php">O Nama</a></li>
                <li><a href="jelovnik.php">Jelovnik</a></li>
                <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </nav>
        <h1>Zavirite u naš jelovnik!</h1>
    </header>
    
    <main>
        <section>
            <table>
                <caption>Juhe</caption>
                <tr>
                    <th>Jelo</th>
                    <th>Cijena</th>
                </tr>
                <?php
                foreach($xml->juhe->dish as $dish) {
                    echo "<tr><td>" . $dish->name . "</td><td>" . $dish->price . "</td></tr>";
                }
                ?>
            </table>
        </section>

        <section>
            <table>
                <caption>Predjela</caption>
                <tr>
                    <th>Jelo</th>
                    <th>Cijena</th>
                </tr>
                <?php
                foreach($xml->predjela->dish as $dish) {
                    echo "<tr><td>" . $dish->name . "</td><td>" . $dish->price . "</td></tr>";
                }
                ?>
            </table>
        </section>

        <section>
            <table>
                <caption>Glavna Jela</caption>
                <tr>
                    <th>Jelo</th>
                    <th>Cijena</th>
                </tr>
                <?php
                foreach($xml->glavnaJela->dish as $dish) {
                    echo "<tr><td>" . $dish->name . "</td><td>" . $dish->price . "</td></tr>";
                }
                ?>
            </table>
        </section>

        <section>
            <table>
                <caption>Deserti</caption>
                <tr>
                    <th>Jelo</th>
                    <th>Cijena</th>
                </tr>
                <?php
                foreach($xml->deserti->dish as $dish) {
                    echo "<tr><td>" . $dish->name . "</td><td>" . $dish->price . "</td></tr>";
                }
                ?>
            </table>
        </section>
    </main>

    <footer>
        <p>Tihana Kos, XML projekt 2024.</p>
    </footer>
</body>
</html>
